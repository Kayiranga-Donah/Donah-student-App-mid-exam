package com.registration.registrationauca.beans;

import com.registration.registrationauca.model.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.UUID;

public class StudentRegistrationBean implements Serializable {
    private UUID reg_id;
    private Student student;
    private AcademicUnit academicUnit;
    private Semester semester;
    private ERegistrationStatus eRegistrationStatus;
    private LocalDate registrationDate;

    public StudentRegistrationBean() {
    }

    public UUID getReg_id() {
        return reg_id;
    }

    public void setReg_id(UUID reg_id) {
        this.reg_id = reg_id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public AcademicUnit getAcademicUnit() {
        return academicUnit;
    }

    public void setAcademicUnit(AcademicUnit academicUnit) {
        this.academicUnit = academicUnit;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }

    public ERegistrationStatus geteRegistrationStatus() {
        return eRegistrationStatus;
    }

    public void seteRegistrationStatus(ERegistrationStatus eRegistrationStatus) {
        this.eRegistrationStatus = eRegistrationStatus;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }
}
