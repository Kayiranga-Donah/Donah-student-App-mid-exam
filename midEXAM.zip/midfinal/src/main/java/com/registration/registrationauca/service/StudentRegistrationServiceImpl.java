package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.StudentDao;
import com.registration.registrationauca.dao.StudentRegistrationDao;
import com.registration.registrationauca.model.Student;
import com.registration.registrationauca.model.StudentRegistration;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class StudentRegistrationServiceImpl extends UnicastRemoteObject implements StudentRegistrationService {
    StudentRegistrationDao studentRegistrationDao = new StudentRegistrationDao();
    StudentDao studentDao = new StudentDao();

    public StudentRegistrationServiceImpl() throws RemoteException {
    }

    @Override
    public void createStudentRegistration(StudentRegistration studentRegistration) throws RemoteException {
        studentRegistrationDao.createStudentRegistration(studentRegistration);
    }

    @Override
    public List<StudentRegistration> fetchAllStudentRegistration() throws RemoteException {
        return studentRegistrationDao.getAllStudentRegistration();
    }

    @Override
    public List<Object[]> getStudents(String studRegNo) throws RemoteException {
        return studentRegistrationDao.getStudents(studRegNo);
    }

    @Override
    public List<Object[]> getAllStudentsRequests() throws RemoteException {
        return studentRegistrationDao.getAllStudentsRequests();
    }

    @Override
    public List<Object[]> getAcademicUnits() throws RemoteException {
        return studentRegistrationDao.getAcademicUnits();
    }

    @Override
    public List<Object[]> getAllSemesters() throws RemoteException {
        return studentRegistrationDao.getAllSemesters();
    }

    @Override
    public Student findById(UUID stud_id) throws RemoteException {
        return studentDao.findById(stud_id);
    }

    @Override
    public boolean rejectStudent(UUID regId) throws RemoteException {
        return studentRegistrationDao.rejectStudent(regId);
    }

    @Override
    public boolean admitStudent(UUID regId) throws RemoteException {
        return studentRegistrationDao.admitStudent(regId);
    }

    @Override
    public StudentRegistration findByIdStudReg(UUID reg_id) throws RemoteException {
        return studentRegistrationDao.findByIdStudReg(reg_id);
    }
}
