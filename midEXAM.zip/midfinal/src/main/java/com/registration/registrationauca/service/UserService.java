package com.registration.registrationauca.service;

import com.registration.registrationauca.model.User;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface UserService extends Remote {
    public void saveUser(User user) throws RemoteException;
    public String getPasswordByEmail(String regNo) throws RemoteException;
}
