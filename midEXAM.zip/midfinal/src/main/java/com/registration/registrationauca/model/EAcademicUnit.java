package com.registration.registrationauca.model;

public enum EAcademicUnit {
    PROGRAMME,
    FACULTY,
    DEPARTMENT
}
