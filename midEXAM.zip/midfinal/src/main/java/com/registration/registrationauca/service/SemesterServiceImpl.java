package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.SemesterDao;
import com.registration.registrationauca.model.Semester;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class SemesterServiceImpl extends UnicastRemoteObject implements SemesterService {
    SemesterDao semesterDao = new SemesterDao();
    public SemesterServiceImpl() throws RemoteException {
    }
    @Override
    public void createSemester(Semester semester) throws RemoteException {
        semesterDao.createSemester(semester);
    }
    @Override
    public List<Semester> fetchAllSemesters() throws RemoteException {
        return semesterDao.getAllSemesters();
    }

    @Override
    public Semester findById(UUID sem_id) throws RemoteException {
        return semesterDao.findById(sem_id);
    }
}
