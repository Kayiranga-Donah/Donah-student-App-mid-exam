package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.Teacher;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;
import java.util.UUID;

public class TeacherDao {
    public boolean createTeacher(Teacher teacher) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(teacher);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Teacher> getAllTeachers() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Teacher";
            Query<Teacher> query = session.createQuery(hql, Teacher.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public Teacher findById(UUID teach_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Teacher WHERE teach_id = :teach_id";
            Query<Teacher> query = session.createQuery(hql, Teacher.class);
            query.setParameter("teach_id", teach_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
