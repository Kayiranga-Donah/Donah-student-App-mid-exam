package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.Course;
import com.registration.registrationauca.model.StudentCourse;
import com.registration.registrationauca.model.StudentRegistration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class StudentCourseDao {
    public boolean createStudentCourse(StudentCourse studentCourse) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(studentCourse);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Object[]> getStudentCourses() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "SELECT sc.stud_course_id, st.regNo, st.fullName, cd.course_def_code, cd.course_name, sc.credits, sc.results FROM CourseDefinition cd JOIN Course c ON cd.course_def_id = c.courseDefinition.course_def_id JOIN StudentCourse sc ON c.course_id = sc.course.course_id JOIN StudentRegistration stu ON stu.reg_id = sc.studentRegistration.reg_id JOIN Student st On st.stud_id = stu.student.stud_id";
            Query<Object[]> query = session.createQuery(hql);
            return query.list();
        } finally {
            session.close();
        }
    }

    public List<Object[]> getAllCourses() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("SELECT cs.course_id,  cd.course_def_code, cd.course_name FROM Course cs JOIN CourseDefinition cd ON cd.course_def_id = cs.courseDefinition.course_def_id").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public List<Object[]> getRegisteredStudents() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("SELECT studreg.reg_id, stud.regNo, stud.fullName FROM StudentRegistration studreg JOIN Student stud ON stud.stud_id = studreg.student.stud_id").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }
}
