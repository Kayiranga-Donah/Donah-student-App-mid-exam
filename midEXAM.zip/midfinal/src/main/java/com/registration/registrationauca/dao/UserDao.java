package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.User;
import com.registration.registrationauca.dao.HibernateUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDao {
    public boolean createUser(User user) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(user);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }

    public User findUser(String regNo) {
        // try-with-resources statement to automatically close the session
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // CriteriaBuilder
            CriteriaBuilder builder = session.getCriteriaBuilder();

            // CriteriaQuery
            CriteriaQuery<User> query = builder.createQuery(User.class);

            // root object
            Root<User> root = query.from(User.class);

            // Add the where condition
            query.select(root).where(builder.equal(root.get("regNo"), regNo));

            // Execute the query and get the result
            return session.createQuery(query).uniqueResult();
        } catch (HibernateException ex) {
            ex.printStackTrace(); // Log the exception message for debugging
            return null;
        }
    }
}
