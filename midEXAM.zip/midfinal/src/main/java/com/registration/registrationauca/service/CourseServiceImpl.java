package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.CourseDao;
import com.registration.registrationauca.model.Course;
import com.registration.registrationauca.model.Student;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class CourseServiceImpl extends UnicastRemoteObject implements CourseService {
    CourseDao courseDao = new CourseDao();

    public CourseServiceImpl() throws RemoteException {
    }
    @Override
    public void createCourse(Course course) throws RemoteException {
        courseDao.createCourse(course);
    }

    @Override
    public List<Course> fetchAllCourses() throws RemoteException {
        return courseDao.getAllCourses();
    }

    @Override
    public List<Object[]> getAcademicUnits() throws RemoteException {
        return courseDao.getAcademicUnits();
    }

    @Override
    public List<Object[]> getCourseDefinition() throws RemoteException {
        return courseDao.getCourseDefinition();
    }

    @Override
    public List<Object[]> getTutorsAndAssistants() throws RemoteException {
        return courseDao.getTutorsAndAssistants();
    }

    @Override
    public List<Object[]> getAllSemesters() throws RemoteException {
        return courseDao.getAllSemesters();
    }

    @Override
    public Course findById(UUID course_id) throws RemoteException {
        return courseDao.findById(course_id);
    }
}
