package com.registration.registrationauca.service;

import com.registration.registrationauca.model.AcademicUnit;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface AcademicUnitService extends Remote {
    public void createAcademicUnit(AcademicUnit academicUnit) throws RemoteException;
    public List<AcademicUnit> fetchAllAcademicUnits() throws RemoteException;
    public AcademicUnit findById(UUID acc_id) throws RemoteException;
}
