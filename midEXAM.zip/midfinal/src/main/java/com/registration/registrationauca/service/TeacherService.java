package com.registration.registrationauca.service;

import com.registration.registrationauca.model.Teacher;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface TeacherService extends Remote {
    public void createTeacher(Teacher teacher) throws RemoteException;
    public List<Teacher> fetchAllTeachers() throws RemoteException;
    public Teacher findById(UUID id) throws RemoteException;
}
