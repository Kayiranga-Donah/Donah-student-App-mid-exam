package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.CourseDefinition;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;
import java.util.UUID;

public class CourseDefinitionDao {
    public boolean createCourseDefinition(CourseDefinition courseDefinition) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(courseDefinition);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<CourseDefinition> getAllCourseDefinitions() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM CourseDefinition";
            Query<CourseDefinition> query = session.createQuery(hql, CourseDefinition.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public CourseDefinition findById(UUID course_def_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM CourseDefinition WHERE course_def_id = :course_def_id";
            Query<CourseDefinition> query = session.createQuery(hql, CourseDefinition.class);
            query.setParameter("course_def_id", course_def_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
