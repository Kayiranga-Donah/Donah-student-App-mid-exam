package com.registration.registrationauca.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
public class Student {
    @Id
    private UUID stud_id;
    private String regNo;
    private String fullName;
    private LocalDate dateOfBirth;

    public Student() {
    }

    @Override
    public String toString() {
        return this.fullName;
    }

    public Student(UUID stud_id, String regNo, String fullName, LocalDate dateOfBirth) {
        this.stud_id = stud_id;
        this.regNo = regNo;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
    }

    public UUID getStud_id() {
        return stud_id;
    }

    public void setStud_id(UUID stud_id) {
        this.stud_id = stud_id;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
