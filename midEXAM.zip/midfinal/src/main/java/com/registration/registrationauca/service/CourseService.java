package com.registration.registrationauca.service;

import com.registration.registrationauca.model.Course;
import com.registration.registrationauca.model.Student;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface CourseService extends Remote {
    public void createCourse(Course course) throws RemoteException;
    public List<Course> fetchAllCourses() throws RemoteException;
    public List<Object[]> getAcademicUnits() throws RemoteException;
    public List<Object[]> getCourseDefinition() throws RemoteException;
    public List<Object[]> getTutorsAndAssistants() throws RemoteException;
    public List<Object[]> getAllSemesters() throws RemoteException;
    public Course findById(UUID course_id) throws RemoteException;
}
