package com.registration.registrationauca.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
public class StudentRegistration {
    @Id
    private UUID reg_id;
    @ManyToOne
    @JoinColumn(name = "student_stud_id")
    private Student student;
    @ManyToOne
    private AcademicUnit academicUnit;
    @ManyToOne
    private Semester semester;
    @Enumerated(EnumType.STRING)
    private ERegistrationStatus eRegistrationStatus;
    private LocalDate registrationDate;

    public StudentRegistration() {
    }

    public StudentRegistration(UUID reg_id, Student student, AcademicUnit academicUnit, Semester semester, ERegistrationStatus eRegistrationStatus, LocalDate registrationDate) {
        this.reg_id = reg_id;
        this.student = student;
        this.academicUnit = academicUnit;
        this.semester = semester;
        this.eRegistrationStatus = eRegistrationStatus;
        this.registrationDate = registrationDate;
    }

    public UUID getReg_id() {
        return reg_id;
    }

    public void setReg_id(UUID reg_id) {
        this.reg_id = reg_id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public AcademicUnit getAcademicUnit() {
        return academicUnit;
    }

    public void setAcademicUnit(AcademicUnit academicUnit) {
        this.academicUnit = academicUnit;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }

    public ERegistrationStatus geteRegistrationStatus() {
        return eRegistrationStatus;
    }

    public void seteRegistrationStatus(ERegistrationStatus eRegistrationStatus) {
        this.eRegistrationStatus = eRegistrationStatus;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }
}
