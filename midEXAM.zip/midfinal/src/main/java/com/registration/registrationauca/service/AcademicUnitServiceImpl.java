package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.AcademicUnitDao;
import com.registration.registrationauca.model.AcademicUnit;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class AcademicUnitServiceImpl extends UnicastRemoteObject implements AcademicUnitService {
    AcademicUnitDao academicUnitDao = new AcademicUnitDao();

    public AcademicUnitServiceImpl() throws RemoteException {
    }

    @Override
    public void createAcademicUnit(AcademicUnit academicUnit) throws RemoteException {
        academicUnitDao.createAcademicUnit(academicUnit);
    }

    @Override
    public List<AcademicUnit> fetchAllAcademicUnits() throws RemoteException {
        return academicUnitDao.getAllAcademicUnits();
    }

    @Override
    public AcademicUnit findById(UUID acc_id) throws RemoteException {
        return academicUnitDao.findById(acc_id);
    }
}
