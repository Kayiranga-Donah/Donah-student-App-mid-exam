package com.registration.registrationauca.beans;

import com.registration.registrationauca.model.*;

import java.io.Serializable;
import java.util.List;

public class CourseBean implements Serializable {
    private AcademicUnit acc_unit;
    private CourseDefinition courseDefinition;
    private Teacher tutor;
    private Teacher assistant;
    private Semester semester;

    public CourseBean() {
    }

    public AcademicUnit getAcc_unit() {
        return acc_unit;
    }

    public void setAcc_unit(AcademicUnit acc_unit) {
        this.acc_unit = acc_unit;
    }

    public CourseDefinition getCourseDefinition() {
        return courseDefinition;
    }

    public void setCourseDefinition(CourseDefinition courseDefinition) {
        this.courseDefinition = courseDefinition;
    }

    public Teacher getTutor() {
        return tutor;
    }

    public void setTutor(Teacher tutor) {
        this.tutor = tutor;
    }

    public Teacher getAssistant() {
        return assistant;
    }

    public void setAssistant(Teacher assistant) {
        this.assistant = assistant;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }
}
