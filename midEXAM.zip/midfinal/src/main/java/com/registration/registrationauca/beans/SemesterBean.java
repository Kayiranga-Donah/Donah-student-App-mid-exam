package com.registration.registrationauca.beans;

import java.io.Serializable;
import java.time.LocalDate;

public class SemesterBean implements Serializable {
    private String sem_code;
    private String name;
    private LocalDate startDate;
    private LocalDate endDate;

    public SemesterBean() {
    }

    public String getSem_code() {
        return sem_code;
    }

    public void setSem_code(String sem_code) {
        this.sem_code = sem_code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
