package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.Semester;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;
import java.util.UUID;

public class SemesterDao {
    public boolean createSemester(Semester semester) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(semester);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Semester> getAllSemesters() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Semester";
            Query<Semester> query = session.createQuery(hql, Semester.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public Semester findById(UUID sem_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Semester WHERE sem_id = :sem_id";
            Query<Semester> query = session.createQuery(hql, Semester.class);
            query.setParameter("sem_id", sem_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
