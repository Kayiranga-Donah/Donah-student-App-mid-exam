package com.registration.registrationauca.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.time.LocalDate;
import java.util.UUID;

@Entity
public class Semester {
    @Id
    private UUID sem_id;
    private String sem_code;
    private String name;
    private LocalDate startDate;
    private LocalDate endDate;
    public Semester() {
    }

    @Override
    public String toString() {
        return this.sem_code + " - " + this.name + ". from " + this.startDate + " to " + this.endDate;
    }

    public Semester(UUID sem_id, String sem_code, String name, LocalDate startDate, LocalDate endDate) {
        this.sem_id = sem_id;
        this.sem_code = sem_code;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public UUID getSem_id() {
        return sem_id;
    }

    public void setSem_id(UUID sem_id) {
        this.sem_id = sem_id;
    }

    public String getSem_code() {
        return sem_code;
    }

    public void setSem_code(String sem_code) {
        this.sem_code = sem_code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
