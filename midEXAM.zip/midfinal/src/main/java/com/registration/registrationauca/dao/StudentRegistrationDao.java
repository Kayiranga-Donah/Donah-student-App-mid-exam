package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.ERegistrationStatus;
import com.registration.registrationauca.model.Student;
import com.registration.registrationauca.model.StudentRegistration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StudentRegistrationDao {
    public boolean createStudentRegistration(StudentRegistration studentRegistration) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(studentRegistration);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<StudentRegistration> getAllStudentRegistration() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM StudentRegistration";
            Query<StudentRegistration> query = session.createQuery(hql, StudentRegistration.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    // reject student
    public boolean rejectStudent(UUID regId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            StudentRegistration studentRegistration = session.get(StudentRegistration.class, regId);
            if (studentRegistration != null) {
                studentRegistration.seteRegistrationStatus(ERegistrationStatus.REJECTED);
                session.update(studentRegistration);
            }
            tx.commit();
            return Boolean.TRUE;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return Boolean.FALSE;
        } finally {
            session.close();
        }
    }

    // admit student
    public boolean admitStudent(UUID regId) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            StudentRegistration studentRegistration = session.get(StudentRegistration.class, regId);
            if (studentRegistration != null) {
                studentRegistration.seteRegistrationStatus(ERegistrationStatus.ADMITTED);
                session.update(studentRegistration);
            }
            tx.commit();
            return Boolean.TRUE;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return Boolean.FALSE;
        } finally {
            session.close();
        }
    }

    // for drop down list

    public List<Object[]> getStudents(String studRegNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("SELECT stureg.reg_id, stu.regNo, stu.fullName, stureg.eRegistrationStatus FROM StudentRegistration stureg JOIN Student stu ON stu.stud_id = stureg.student.stud_id where stu.regNo = '"+studRegNo+"'").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }
    public List<Object[]> getAllStudentsRequests() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("SELECT stureg.reg_id, stu.regNo, stu.fullName, stureg.eRegistrationStatus FROM StudentRegistration stureg JOIN Student stu ON stu.stud_id = stureg.student.stud_id").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public List<Object[]> getAcademicUnits() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select au.acc_id, au.name from AcademicUnit au where au.unit = 'DEPARTMENT'").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public List<Object[]> getAllSemesters() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select sem.sem_id, sem.sem_code, sem.name, sem.startDate, sem.endDate from Semester sem").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public StudentRegistration findByIdStudReg(UUID reg_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM StudentRegistration WHERE reg_id = :reg_id";
            Query<StudentRegistration> query = session.createQuery(hql, StudentRegistration.class);
            query.setParameter("reg_id", reg_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
