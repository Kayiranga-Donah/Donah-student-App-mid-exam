package com.registration.registrationauca.model;

import com.registration.registrationauca.dao.HibernateUtil;

public class TestModel {
    public static void main(String[] args) {
        HibernateUtil.getSessionFactory().openSession();
    }
}
