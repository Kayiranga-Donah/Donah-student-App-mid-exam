package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.CourseDefinitionDao;
import com.registration.registrationauca.model.CourseDefinition;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class CourseDefinitionServiceImpl extends UnicastRemoteObject implements CourseDefinitionService {

    CourseDefinitionDao courseDefinitionDao = new CourseDefinitionDao();

    public CourseDefinitionServiceImpl() throws RemoteException {
    }

    @Override
    public void createCourseDefinition(CourseDefinition courseDefinition) throws RemoteException {
        courseDefinitionDao.createCourseDefinition(courseDefinition);
    }

    @Override
    public List<CourseDefinition> fetchAllCourseDefinition() throws RemoteException {
        return courseDefinitionDao.getAllCourseDefinitions();
    }

    @Override
    public CourseDefinition findById(UUID id) throws RemoteException {
        return courseDefinitionDao.findById(id);
    }
}
