package com.registration.registrationauca.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
public class StudentCourse {
    @Id
    private UUID stud_course_id;
    private Integer credits;
    private BigDecimal results;
    @ManyToOne
    private Course course;
    @ManyToOne
    private StudentRegistration studentRegistration;

    public StudentCourse() {
    }

    public StudentCourse(UUID stud_course_id, Integer credits, BigDecimal results, Course course, StudentRegistration studentRegistration) {
        this.stud_course_id = stud_course_id;
        this.credits = credits;
        this.results = results;
        this.course = course;
        this.studentRegistration = studentRegistration;
    }

    public UUID getStud_course_id() {
        return stud_course_id;
    }

    public void setStud_course_id(UUID stud_course_id) {
        this.stud_course_id = stud_course_id;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public BigDecimal getResults() {
        return results;
    }

    public void setResults(BigDecimal results) {
        this.results = results;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public StudentRegistration getStudentRegistration() {
        return studentRegistration;
    }

    public void setStudentRegistration(StudentRegistration studentRegistration) {
        this.studentRegistration = studentRegistration;
    }
}
