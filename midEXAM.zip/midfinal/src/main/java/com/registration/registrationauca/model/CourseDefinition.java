package com.registration.registrationauca.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.UUID;

@Entity
public class CourseDefinition {
    @Id
    private UUID course_def_id;
    private String course_def_code;
    private String course_name;
    private String course_description;

    public CourseDefinition() {
    }

    @Override
    public String toString() {
        return this.course_name;
    }

    public CourseDefinition(UUID course_def_id, String course_def_code, String course_name, String course_description) {
        this.course_def_id = course_def_id;
        this.course_def_code = course_def_code;
        this.course_name = course_name;
        this.course_description = course_description;
    }

    public UUID getCourse_def_id() {
        return course_def_id;
    }

    public void setCourse_def_id(UUID course_def_id) {
        this.course_def_id = course_def_id;
    }

    public String getCourse_def_code() {
        return course_def_code;
    }

    public void setCourse_def_code(String course_def_code) {
        this.course_def_code = course_def_code;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public String getCourse_description() {
        return course_description;
    }

    public void setCourse_description(String course_description) {
        this.course_description = course_description;
    }
}
