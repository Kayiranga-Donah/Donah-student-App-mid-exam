package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.StudentDao;
import com.registration.registrationauca.model.Student;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class StudentServiceImpl extends UnicastRemoteObject implements StudentService {
    StudentDao studentDao = new StudentDao();

    public StudentServiceImpl() throws RemoteException {
    }

    @Override
    public void createStudent(Student student) throws RemoteException {
        studentDao.createStudent(student);
    }

    @Override
    public List<Student> fetchAllStudents(String regNo) throws RemoteException {
        return studentDao.getAllStudents(regNo);
    }

    @Override
    public Student findById(UUID stud_id) throws RemoteException {
        return studentDao.findById(stud_id);
    }

    @Override
    public Student findByRegNo(String regNo) throws RemoteException {
        return studentDao.findByRegNo(regNo);
    }
}
