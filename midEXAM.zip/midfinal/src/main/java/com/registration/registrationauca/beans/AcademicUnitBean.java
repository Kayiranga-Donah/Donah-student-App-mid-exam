package com.registration.registrationauca.beans;

import com.registration.registrationauca.model.*;

import java.io.Serializable;
import java.util.UUID;

public class AcademicUnitBean implements Serializable {
    private UUID acc_id;
    private String acc_code;
    private String name;
    private EAcademicUnit unit;
    private AcademicUnit parent;

    public AcademicUnitBean() {
    }

    public UUID getAcc_id() {
        return acc_id;
    }

    public void setAcc_id(UUID acc_id) {
        this.acc_id = acc_id;
    }

    public String getAcc_code() {
        return acc_code;
    }

    public void setAcc_code(String acc_code) {
        this.acc_code = acc_code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EAcademicUnit getUnit() {
        return unit;
    }

    public void setUnit(EAcademicUnit unit) {
        this.unit = unit;
    }

    public AcademicUnit getParent() {
        return parent;
    }

    public void setParent(AcademicUnit parent) {
        this.parent = parent;
    }
}
