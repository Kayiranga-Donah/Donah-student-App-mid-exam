package com.registration.registrationauca.service;

import com.registration.registrationauca.model.Course;
import com.registration.registrationauca.model.StudentCourse;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface StudentCourseService extends Remote {
    public void createStudentCourse(StudentCourse studentCourse) throws RemoteException;
    public List<Object[]> fetchAllStudentCourses() throws RemoteException;
    public List<Object[]> getAllCourses() throws RemoteException;
    public List<Object[]> getRegisteredStudents() throws RemoteException;
}
