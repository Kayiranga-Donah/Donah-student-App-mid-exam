package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.AcademicUnit;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;
import java.util.UUID;

public class AcademicUnitDao {
    public boolean createAcademicUnit(AcademicUnit academicUnit) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(academicUnit);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<AcademicUnit> getAllAcademicUnits() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM AcademicUnit";
            Query<AcademicUnit> query = session.createQuery(hql, AcademicUnit.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public AcademicUnit findById(UUID acc_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM AcademicUnit WHERE acc_id = :acc_id";
            Query<AcademicUnit> query = session.createQuery(hql, AcademicUnit.class);
            query.setParameter("acc_id", acc_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
