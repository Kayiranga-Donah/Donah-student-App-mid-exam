package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.TeacherDao;
import com.registration.registrationauca.model.Teacher;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class TeacherServiceImpl extends UnicastRemoteObject implements TeacherService {
    TeacherDao teacherDao = new TeacherDao();

    public TeacherServiceImpl() throws RemoteException {
    }

    @Override
    public void createTeacher(Teacher teacher) throws RemoteException {
        teacherDao.createTeacher(teacher);
    }

    @Override
    public List<Teacher> fetchAllTeachers() throws RemoteException {
        return teacherDao.getAllTeachers();
    }

    @Override
    public Teacher findById(UUID id) throws RemoteException {
        return teacherDao.findById(id);
    }
}
