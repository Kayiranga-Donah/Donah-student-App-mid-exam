package com.registration.registrationauca.model;

public enum EQualification {
    MASTER,
    PHD,
    PROFESSOR
}
