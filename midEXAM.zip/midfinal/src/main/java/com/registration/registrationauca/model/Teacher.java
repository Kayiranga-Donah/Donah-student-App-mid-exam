package com.registration.registrationauca.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import java.util.UUID;

@Entity
public class Teacher {
    @Id
    private UUID teach_id;
    private String teacher_code;
    private String teacher_name;
    @Enumerated(EnumType.STRING)
    private EQualification qualification;

    public Teacher() {
    }

    @Override
    public String toString() {
        return this.teacher_name;
    }

    public Teacher(UUID teach_id, String teacher_code, String teacher_name, EQualification qualification) {
        this.teach_id = teach_id;
        this.teacher_code = teacher_code;
        this.teacher_name = teacher_name;
        this.qualification = qualification;
    }

    public UUID getTeach_id() {
        return teach_id;
    }

    public void setTeach_id(UUID teach_id) {
        this.teach_id = teach_id;
    }

    public String getTeacher_code() {
        return teacher_code;
    }

    public void setTeacher_code(String teacher_code) {
        this.teacher_code = teacher_code;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public EQualification getQualification() {
        return qualification;
    }

    public void setQualification(EQualification qualification) {
        this.qualification = qualification;
    }
}
