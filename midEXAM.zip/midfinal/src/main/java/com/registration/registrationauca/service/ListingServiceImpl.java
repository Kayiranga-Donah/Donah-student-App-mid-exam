package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.ListingDao;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.UUID;

public class ListingServiceImpl extends UnicastRemoteObject implements ListingService{
    ListingDao listingDao = new ListingDao();

    public ListingServiceImpl() throws RemoteException {
    }

    @Override
    public List<Object[]> listStudentsByCourse(UUID course_id) throws RemoteException {
        return listingDao.getStudentsByCourse(course_id);
    }

    @Override
    public List<Object[]> listStudentsByDepartment(UUID acc_id) throws RemoteException {
        return listingDao.getStudentsByDepartment(acc_id);
    }

    @Override
    public List<Object[]> listCoursesByStudent(UUID course_id) throws RemoteException {
        return listingDao.getCoursesByStudent(course_id);
    }

    @Override
    public List<Object[]> listCoursesByDepartment(UUID course_id) throws RemoteException {
        return listingDao.getCoursesByDepartment(course_id);
    }

    @Override
    public List<Object[]> listStudentsBySemester(UUID stud_id) throws RemoteException {
        return listingDao.getStudentsBySemester(stud_id);
    }
}
