package com.registration.registrationauca.service;

import com.registration.registrationauca.model.CourseDefinition;

import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface CourseDefinitionService {
    public void createCourseDefinition(CourseDefinition courseDefinition) throws RemoteException;
    public List<CourseDefinition> fetchAllCourseDefinition() throws RemoteException;
    public CourseDefinition findById(UUID id) throws RemoteException;
}
