package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.Student;
import org.hibernate.*;
import org.hibernate.query.Query;

import java.util.List;
import java.util.UUID;

public class StudentDao {
    public boolean createStudent(Student student) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(student);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Student> getAllStudents(String regNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Student WHERE regNo = '"+regNo+"'";
            Query<Student> query = session.createQuery(hql, Student.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public Student findById(UUID stud_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Student WHERE stud_id = :stud_id";
            Query<Student> query = session.createQuery(hql, Student.class);
            query.setParameter("stud_id", stud_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
    public Student findByRegNo(String regNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Student WHERE regNo = :regNo";
            Query<Student> query = session.createQuery(hql, Student.class);
            query.setParameter("regNo", regNo);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }
}
