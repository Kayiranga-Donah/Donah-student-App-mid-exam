package com.registration.registrationauca.beans;

import java.io.Serializable;

public class CourseDefinitionBean implements Serializable {
    private String course_def_code;
    private String course_name;
    private String course_description;

    public CourseDefinitionBean() {
    }

    public String getCourse_def_code() {
        return course_def_code;
    }

    public void setCourse_def_code(String course_def_code) {
        this.course_def_code = course_def_code;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public String getCourse_description() {
        return course_description;
    }

    public void setCourse_description(String course_description) {
        this.course_description = course_description;
    }
}
