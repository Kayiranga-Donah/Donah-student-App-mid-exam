package com.registration.registrationauca.model;

public enum ERegistrationStatus {
    PENDING,
    ADMITTED,
    REJECTED
}
