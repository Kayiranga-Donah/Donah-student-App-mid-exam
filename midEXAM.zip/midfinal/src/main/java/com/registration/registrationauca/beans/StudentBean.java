package com.registration.registrationauca.beans;

import java.io.Serializable;
import java.util.UUID;

public class StudentBean implements Serializable {
    private UUID stud_id;
    private String regNo;
    private String fullName;
    private String dateOfBirth;

    public StudentBean() {
    }

    public StudentBean(UUID stud_id, String regNo, String fullName, String dateOfBirth) {
        this.stud_id = stud_id;
        this.regNo = regNo;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
    }

    public UUID getStud_id() {
        return stud_id;
    }

    public void setStud_id(UUID stud_id) {
        this.stud_id = stud_id;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
