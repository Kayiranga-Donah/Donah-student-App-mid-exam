package com.registration.registrationauca.dao;

import com.registration.registrationauca.model.Course;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CourseDao {
    public boolean createCourse(Course course) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(course);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Course> getAllCourses() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Course";
            Query<Course> query = session.createQuery(hql, Course.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    // for dropdownlist
    public List<Object[]> getAcademicUnits() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select au.acc_id, au.name from AcademicUnit au where au.unit = 'DEPARTMENT'").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public List<Object[]> getAllSemesters() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select sem.sem_id, sem.sem_code, sem.name, sem.startDate, sem.endDate from Semester sem").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public List<Object[]> getCourseDefinition() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select cd.course_def_id, cd.course_name from CourseDefinition cd").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }


    public List<Object[]> getTutorsAndAssistants() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Object[]> results = new ArrayList<>();
        try {
            results = session.createQuery("select t.teach_id, t.teacher_name from Teacher t").list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    public Course findById(UUID course_id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Course WHERE course_id = :course_id";
            Query<Course> query = session.createQuery(hql, Course.class);
            query.setParameter("course_id", course_id);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }

}
