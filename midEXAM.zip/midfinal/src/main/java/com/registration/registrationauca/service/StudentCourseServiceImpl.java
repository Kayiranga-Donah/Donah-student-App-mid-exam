package com.registration.registrationauca.service;

import com.registration.registrationauca.dao.StudentCourseDao;
import com.registration.registrationauca.model.StudentCourse;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class StudentCourseServiceImpl extends UnicastRemoteObject implements StudentCourseService {
    StudentCourseDao studentCourseDao = new StudentCourseDao();

    public StudentCourseServiceImpl() throws RemoteException {
    }

    @Override
    public void createStudentCourse(StudentCourse studentCourse) throws RemoteException {
        studentCourseDao.createStudentCourse(studentCourse);
    }

    @Override
    public List<Object[]> fetchAllStudentCourses() throws RemoteException {
        return studentCourseDao.getStudentCourses();
    }

    @Override
    public List<Object[]> getAllCourses() throws RemoteException {
        return studentCourseDao.getAllCourses();
    }

    @Override
    public List<Object[]> getRegisteredStudents() throws RemoteException {
        return studentCourseDao.getRegisteredStudents();
    }
}
