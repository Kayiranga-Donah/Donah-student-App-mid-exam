package com.registration.registrationauca.beans;

import com.registration.registrationauca.model.Course;
import com.registration.registrationauca.model.StudentRegistration;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

public class StudentCourseBean implements Serializable {
    private UUID stud_course_id;
    private Integer credits;
    private BigDecimal results;
    private Course course;
    private StudentRegistration studentRegistration;

    public StudentCourseBean() {
    }

    public UUID getStud_course_id() {
        return stud_course_id;
    }

    public void setStud_course_id(UUID stud_course_id) {
        this.stud_course_id = stud_course_id;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public BigDecimal getResults() {
        return results;
    }

    public void setResults(BigDecimal results) {
        this.results = results;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public StudentRegistration getStudentRegistration() {
        return studentRegistration;
    }

    public void setStudentRegistration(StudentRegistration studentRegistration) {
        this.studentRegistration = studentRegistration;
    }
}
