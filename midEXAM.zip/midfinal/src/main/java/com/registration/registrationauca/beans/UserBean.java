package com.registration.registrationauca.beans;

import java.io.Serializable;

public class UserBean implements Serializable {
    private String regNo;
    private String password;
    private String role;

    public UserBean() {
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
