package com.registration.registrationauca.beans;

import com.registration.registrationauca.model.EQualification;

import java.io.Serializable;

public class TeacherBean implements Serializable {
    private String teacher_code;
    private String teacher_name;
    private EQualification qualification;

    public TeacherBean() {
    }

    public String getTeacher_code() {
        return teacher_code;
    }

    public void setTeacher_code(String teacher_code) {
        this.teacher_code = teacher_code;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public EQualification getQualification() {
        return qualification;
    }

    public void setQualification(EQualification qualification) {
        this.qualification = qualification;
    }
}