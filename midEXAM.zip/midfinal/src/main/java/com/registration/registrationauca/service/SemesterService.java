package com.registration.registrationauca.service;

import com.registration.registrationauca.model.Semester;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface SemesterService extends Remote {
    public void createSemester(Semester semester) throws RemoteException;
    public List<Semester> fetchAllSemesters() throws RemoteException;
    public Semester findById(UUID sem_id) throws RemoteException;
}
