package com.registration.registrationauca.service;

import com.registration.registrationauca.model.Student;
import com.registration.registrationauca.model.StudentRegistration;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public interface StudentRegistrationService extends Remote {
    public void createStudentRegistration(StudentRegistration studentRegistration) throws RemoteException;
    public List<StudentRegistration> fetchAllStudentRegistration() throws RemoteException;
    public List<Object[]> getStudents(String studRegNo) throws RemoteException;
    public List<Object[]> getAllStudentsRequests() throws RemoteException;
    public List<Object[]> getAcademicUnits() throws RemoteException;
    public List<Object[]> getAllSemesters() throws RemoteException;
    public Student findById(UUID stud_id) throws RemoteException;
    public boolean rejectStudent(UUID regId) throws RemoteException;
    public boolean admitStudent(UUID regId) throws RemoteException;
    public StudentRegistration findByIdStudReg(UUID reg_id) throws RemoteException;
}
